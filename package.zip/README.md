# 思源笔记文档助手，协助你整理笔记的好帮手

思源笔记文档助手 siyuan-doc-assist 是一个思源笔记插件，用于增强思源笔记本体未提供的文档处理和编辑功能。

- 插件 ID：`siyuan-doc-assist`
- 展示名称：`文档助手 / Doc Assist`
- 最低思源版本：`3.5.7`

## Development & Docs

- Common commands: `pnpm install`, `pnpm dev`, `pnpm build`, `pnpm test`, `pnpm typecheck:strict`
- Structure snapshot: `docs/project-structure.md`
- Refactor plan and progress: `docs/refactor-plan.md`
- Action runner structure: `src/plugin/action-runner.ts` keeps runtime guards and dispatch, while `src/plugin/action-runner-*-handlers.ts` carries grouped action logic.
- Lifecycle structure: `src/plugin/plugin-lifecycle.ts` remains the composition root, while `src/plugin/plugin-lifecycle-menu.ts` and `src/plugin/plugin-lifecycle-state.ts` own menu composition and persisted menu state.
- Key-info structure: `src/plugin/key-info-controller.ts` keeps refresh/navigation/export orchestration, `src/plugin/key-info-controller-dock.ts` bridges dock callbacks, and `src/ui/key-info-dock-controls.ts` builds the dock control shell.
- Cleanup structure: `src/core/markdown-cleanup-core.ts` now stays as the public facade, while `src/core/markdown-cleanup-text-core.ts`, `src/core/markdown-cleanup-ai-core.ts`, and `src/core/markdown-cleanup-block-core.ts` carry the internal transform families.

## 功能总览

插件安装后会生成一个侧边栏，目前主要提供两大类功能：

### 1. 关键内容

- 自动提取文档中加了标记的关键内容：标题、加粗、斜体、高亮、备注、标签；
- 支持类型多选筛选、手动刷新；
- 点击条目可在当前文档中平滑定位到对应块；
- 支持将当前筛选结果导出为 Markdown；通过文档处理命令支持批量导出子文档关键内容；

![image](https://github.com/famotime/siyuan-doc-assist/blob/main/assets/image-20260222174322-tnvviaq.png?raw=1)

多说一句，集市里有一个叫“关键信息导航”的插件，提供类似的功能。但我试用了有问题，很多文档的加粗内容显示不全，顺序跟原文也不一致，好像还不支持导出，作者也有几个月没更新了，所以就自己折腾一个。

### 2. 文档处理

- **导出：**

  - 仅导出当前文档、打包导出反链文档、打包导出正链文档：当前思源笔记已经内置了是否导出关联文档的配置项，但我有多种导出需求，又嫌更改配置太麻烦，现在就可以两全其美了。
  使用思源笔记内置导出功能可以打包导出关联文档，而通过文档助手可以仅导出单文档，或者仅打包导出正链文档，或仅打包导出反链文档。
  
  - 打包导出子文档关键内容：一键打包导出本文档及子文档关键内容； 

- **整理：**

  - 移动反链/正链文档为子文档：是为了方便整理笔记归类，大多数时候我就用链接关联四散的笔记文档，但对于某一个准备深入研究的主题，我还是习惯把关联文档都作为子文档，放在主题笔记节点之下。

  - 识别本层级重复文档：也是为了整理方便，有时候从公众号、头条号不同数据源采集了很多文章准备有空了慢慢看，难免会发生保存了重复文档的情况，使用这个功能可以帮助简单识别。识别出来后可以全部打开对比，再删除冗余。
  
- **插入：**

  - 插入反链和插入子文档列表（去重）：这个功能其他插件也有，我增加了一个去重比较的体验改进点，每次只插入文档正文中未包含的关联文档链接。我自己整理的主题笔记，通常都包含了有层次关系的链接，但笔记是慢慢积累的，如果每次都全量插入关联文档链接，从头整理层次关系太费劲了，所以只插入新文档链接，只做增量整理。

  - 链接-引用批量互转：有时会纠结使用链接还是引用，此功能可以将本文档的链接一键转为引用，或者把引用全部转为链接；反正随时可以转换，以后就不用纠结了；

  - 标示无效链接/引用：主题文档是需要持续维护的，本功能用于识别本文档中的无效链接或引用，并增加删除线和高亮处理，便于进一步清理；每次仅清理无效链接，而无须重头构建，维护就轻松一些了。

  - 标题前增加空段落：让段落层次更分明一些。

- **编辑：**

  - 选中块批量加粗/高亮：支持选中多个块批量操作；

  - 选中内容换行-分段互转：有时需要把一个段落的换行文本转化为独立段落块，有时需要反过来把多个块内容合并为一个段落块，通过此命令可以快捷转换；

  - 选中内容中英文标点互转：默认英文标点转中文标点，再次操作则反向转换；

  - 选中内容删除空格：删除选中内容中的所有空格、Tab、零宽字符、制表符；如果选中多个块，则对这些块批量操作；

  - 清理行尾空格（含Tab）：删除本文档中所有行尾空格，含Tab；

  - 清理AI输出内容：实验性功能。目前主要用于清理AI输出deep research报告中的脚注，初步适配了Gemini和Perplexity的输出样式；

  - 去除本文档空段落：让文档内容更加紧凑；

  - 删除后续段落：很多从公众号剪藏的文章末尾都有很多冗余信息，可以借助此功能批量删除末尾冗余段落；

- **图片：**

  - 批量转换为WebP：可以大幅缩减文档中的图片大小；

  - 批量转换为PNG：对应有些使用场景只支持PNG图片，便于导出处理；

  - 按当前显示调整图片大小：根据本文档中的图片显示宽度，调整图片尺寸大小，用于压缩图片存储空间；

  - 删除本文档图片：用于提取纯文本内容；

![image](https://github.com/famotime/siyuan-doc-assist/blob/main/assets/image-20260222174713-dh2y23m.png?raw=1)

### 使用入口

- 右侧 Dock 面板：提供“关键内容 / 文档处理”双标签页；

- 编辑器标题菜单：可选择全部或部分命令注册到标题菜单；

- 命令面板：可执行全部插件命令；

- 部分动作为桌面端限定，移动端会自动置灰并给出提示；


## 重要说明

“文档处理”相关操作命令涉及文档内容编辑（此类变更无法使用编辑回退，只能通过思源笔记的“数据历史”恢复）以及文档路径变更，存在一定风险。

本插件在发布前虽已经过开发者本人试用验证，但仍可能有不可预知的Bug，建议不要在重要文档使用。
